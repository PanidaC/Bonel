.mySlides {
	display: none;
	height: 100%;
	font-family: Arial,Helvetica,sans-serif;
}
.mySlides img {
	width: 100%;
	height: 100%;
}
.slideshow-container {
	overflow: hidden;
	position: relative;
	margin: auto;
	width: 1280px;
	height: 500px;
}
.slide-prev, .slide-next {
	cursor: pointer;
	position: absolute;
	top: 50%;
	width: auto;
	padding: 16px;
	margin-top: -22px;
	color: white;
	font-weight: bold;
	font-size: 18px;
	transition: 0.6s ease;
	border-radius: 0 3px 3px 0;
}
.slide-next {
	right: 0;
	border-radius: 3px 0 0 3px;
}
.slide-prev:hover, .slide-next:hover {
	background-color: rgba(0,0,0,0.8);
}
.slide-number {
	color: #f2f2f2;
	font-size: 12px;
	padding: 8px 12px;
	position: absolute;
	top: 0;
}

/************CSS Animation***********/

.animated { 
   -webkit-animation-name: fadeIn; 
           animation-name: fadeIn; 
   -webkit-animation-duration: 1s; 
           animation-duration: 1s; 
} 
@-webkit-keyframes fadeIn { 
    0% {opacity: 0;} 
    100% {opacity: 1;} 
} 
@keyframes fadeIn { 
    0% {opacity: 0;} 
    100% {opacity: 1;} 
} 
.fadeIn { 
    -webkit-animation-name: fadeIn; 
    animation-name: fadeIn; 
}


